# Implementación — Rediseño ejecutivo oscuro de la landing

Archivos listos para copiar sobre tu codebase Next.js (`Distribution ERP`):

| Archivo aquí | Destino en tu repo |
|---|---|
| `layout.tsx` | `app/(marketing)/layout.tsx` |
| `landing.css` | `app/(marketing)/landing.css` |
| `page.tsx` | `app/(marketing)/page.tsx` |
| `site-header.tsx` | `app/(marketing)/_components/site-header.tsx` |
| `site-footer.tsx` | `app/(marketing)/_components/site-footer.tsx` |

## Qué cambia

- **Tema oscuro ejecutivo**: fondo `#0A1014`, cards `#10191E`, acento teal `#3AE6D1` (evolución del `#0F8B8D` de marca).
- **Fuentes**: Archivo + IBM Plex Mono vía `next/font/google` (cero requests externos en runtime, self-hosted por Next).
- **Hero centrado** con badge animado, título con degradado y mock de dashboard oscuro más realista (sidebar con módulos reales, KPIs, gráfico).
- **Nueva sección "Operación conectada"** (`#plataforma`): el flujo Pedido → Stock → Entrega → Cobranza → Caja → Decisión de tu brand platform.
- Se mantienen intactos: `TrackedLink` (analytics), `LandingEffects` (reveal on scroll + navbar `.scrolled`), `CONTACT`/`LEGAL`, metadata SEO, accesibilidad (`aria-*`, reduced-motion) y el scope `.landing`.
- Header ahora incluye link **Ingresar** (`/login`) además del CTA.
- Nav actualizada: Plataforma / Módulos / Seguridad / FAQ.

## Notas

- Las páginas legales (`/terms`, `/privacy`, `/delete-account`) heredan el tema oscuro automáticamente (los estilos `.legal-body` fueron adaptados).
- Si `LandingEffects` referencia clases del CSS viejo, no requiere cambios: usa `data-animate`/`.visible` y `#navbar`/`.scrolled`, que se conservan.
- El mock del hero es decorativo (`role="img"` + `aria-hidden` en detalles), igual que antes.
- Cuando tengas el logo real, reemplazá `BrandMark` en `site-header.tsx`.
