// =============================================================================
// Footer del sitio de marketing — rediseño ejecutivo oscuro
// Reemplaza: app/(marketing)/_components/site-footer.tsx
// =============================================================================

import { CONTACT, LEGAL } from "@/lib/marketing/contact";
import { Brand } from "./site-header";
import { TrackedLink } from "./tracked-link";

export function SiteFooter() {
  return (
    <footer id="contacto">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <Brand />
            <p>
              Sistema de gestión 100% web para negocios mayoristas y de
              distribución de Argentina.
            </p>
          </div>
          <div>
            <h4>Producto</h4>
            <ul>
              <li><a href="/#plataforma">Plataforma</a></li>
              <li><a href="/#modulos">Módulos</a></li>
              <li><a href="/#seguridad">Seguridad</a></li>
              <li><a href="/#faq">Preguntas frecuentes</a></li>
            </ul>
          </div>
          <div>
            <h4>Contacto</h4>
            <ul>
              <li>
                <a href={`mailto:${CONTACT.email}`}>Escribinos por email</a>
              </li>
              <li>
                <TrackedLink
                  event="whatsapp_click"
                  eventProps={{ section: "footer" }}
                  href={CONTACT.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Hablar por WhatsApp
                </TrackedLink>
              </li>
              <li><a href="/terms">Términos y Condiciones</a></li>
              <li><a href="/privacy">Política de Privacidad</a></li>
              <li><a href="/delete-account">Eliminación de cuenta</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 {LEGAL.ownerDisplayName} · {LEGAL.jurisdiction}</span>
          <span className="credit">
            Desarrollado por{" "}
            <a href={CONTACT.servitecUrl} target="_blank" rel="noopener noreferrer">
              {LEGAL.developerName}
            </a>
          </span>
        </div>
      </div>
    </footer>
  );
}
