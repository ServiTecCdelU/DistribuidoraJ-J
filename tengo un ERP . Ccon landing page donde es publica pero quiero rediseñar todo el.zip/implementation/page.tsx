// =============================================================================
// Landing pública "/" — rediseño ejecutivo oscuro (v2)
// Reemplaza: app/(marketing)/page.tsx
// =============================================================================
// Server Component. Mantiene TrackedLink, LandingEffects (reveal + navbar
// scrolled), CONTACT y metadata. Nueva estructura: hero centrado con mock
// oscuro, sección "Operación conectada" (flujo), problema, beneficios,
// módulos, pasos, seguridad, FAQ y CTA final.
// =============================================================================

import type { Metadata } from "next";
import { CONTACT, PRODUCT_NAME } from "@/lib/marketing/contact";
import { getMarketingBaseUrl } from "@/lib/marketing/site";
import { LandingEffects } from "./_components/landing-effects";
import { SiteHeader } from "./_components/site-header";
import { SiteFooter } from "./_components/site-footer";
import { TrackedLink } from "./_components/tracked-link";

const TITLE =
  "Distribution Platform — Sistema de gestión para tu negocio | Stock, ventas, cuenta corriente y reparto";
const DESCRIPTION =
  "Software de gestión 100% web para negocios mayoristas y de distribución de Argentina. Controlá stock, ventas, cuenta corriente, caja diaria y reparto desde un solo lugar. Probalo gratis 14 días.";

export function generateMetadata(): Metadata {
  const base = getMarketingBaseUrl();
  return {
    title: TITLE,
    description: DESCRIPTION,
    metadataBase: new URL(base),
    alternates: { canonical: "/" },
    openGraph: {
      title: TITLE,
      description: DESCRIPTION,
      url: base,
      siteName: PRODUCT_NAME,
      locale: "es_AR",
      type: "website",
    },
    robots: { index: true, follow: true },
  };
}

function WhatsAppIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2a10 10 0 0 0-8.7 15L2 22l5.2-1.3A10 10 0 1 0 12 2zm5.3 14.1c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.4-.7-2.9-1.2-4.7-4.1-4.9-4.3-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5s.8 1.9.8 2c.1.1.1.3 0 .5-.3.6-.6.8-.4 1.1.7 1.2 1.6 2 2.8 2.6.3.2.5.1.7-.1l.7-.8c.2-.3.4-.2.7-.1s1.7.8 2 1c.3.1.5.2.5.3.1.1.1.7-.1 1.3z" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M5 12h14" />
      <path d="M13 6l6 6-6 6" />
    </svg>
  );
}

function Check() {
  return (
    <span className="check">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M20 6L9 17l-5-5" />
      </svg>
    </span>
  );
}

const S = {
  width: 19,
  height: 19,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
} as const;

interface ModuleCardProps {
  title: string;
  text: string;
  soon?: boolean;
  icon: React.ReactNode;
}

function ModuleCard({ title, text, soon, icon }: ModuleCardProps) {
  return (
    <div className="module-card">
      {soon ? <span className="badge-soon">Próximamente</span> : null}
      <span className="icon">{icon}</span>
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}

const FLOW_STEPS = ["Pedido", "Stock", "Entrega", "Cobranza", "Caja"];

const SIDE_ITEMS = [
  { label: "Panel", active: true, icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M3 21V7" /><path d="M8 21V3" /><path d="M13 21v-8" /><path d="M18 21V11" /></svg> },
  { label: "Ventas", icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><circle cx="9" cy="20" r="1.6" /><circle cx="18" cy="20" r="1.6" /><path d="M2 3h3l3 13h11l2-8H7" /></svg> },
  { label: "Stock", icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z" /><path d="M3 8l9 5 9-5" /></svg> },
  { label: "Cta. corriente", icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18" /></svg> },
  { label: "Caja diaria", icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><rect x="2" y="6" width="20" height="12" rx="2" /><circle cx="12" cy="12" r="2.6" /></svg> },
  { label: "Reparto", icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M1 8h13v9H1z" /><path d="M14 11h4l3 3v3h-7z" /><circle cx="6" cy="18" r="1.6" /><circle cx="17" cy="18" r="1.6" /></svg> },
  { label: "Compras", icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M16 3h5v5" /><path d="M21 3l-7 7" /><path d="M12 14v7" /><path d="M8 21h8" /></svg> },
];

const CHART_BARS = [
  { height: "38%" },
  { height: "55%" },
  { height: "78%", hi: true },
  { height: "50%" },
  { height: "66%" },
  { height: "92%", hi: true },
  { height: "60%" },
];

export default function LandingPage() {
  return (
    <>
      <LandingEffects />
      <SiteHeader />

      <main>
        {/* HERO */}
        <section className="hero" aria-labelledby="hero-heading">
          <div className="container">
            <div className="hero-badge">
              <span className="pulse" aria-hidden="true" />
              ERP para distribución · Argentina
            </div>
            <h1 id="hero-heading">
              Toda tu operación,
              <br />
              <span className="grad">bajo control.</span>
            </h1>
            <p className="sub">
              Stock, ventas, cuenta corriente, caja y reparto conectados en una
              sola plataforma. 100% web, pensada para cómo se trabaja en
              Argentina.
            </p>
            <div className="hero-ctas">
              <TrackedLink event="hero_cta_click" eventProps={{ cta: "hero" }} className="btn btn-primary" href="/signup">
                Probar gratis 14 días
                <ArrowIcon />
              </TrackedLink>
              <TrackedLink
                event="whatsapp_click"
                eventProps={{ section: "hero" }}
                className="btn btn-ghost"
                href={CONTACT.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                <WhatsAppIcon />
                Hablar por WhatsApp
              </TrackedLink>
            </div>
            <p className="micro">Sin tarjeta · Sin instalación · Importás tu Excel y arrancás</p>

            {/* DASHBOARD MOCK */}
            <div className="mock-wrap">
              <div className="browser" role="img" aria-label="Vista del panel del sistema con indicadores de ventas, stock y caja">
                <div className="browser-bar">
                  <span className="dot" /><span className="dot" /><span className="dot" />
                  <span className="browser-url">app.distributionplatform.com</span>
                </div>
                <div className="dash">
                  <div className="dash-side" aria-hidden="true">
                    <div className="side-label">Operación</div>
                    {SIDE_ITEMS.map((item) => (
                      <div key={item.label} className={item.active ? "side-item active" : "side-item"}>
                        {item.icon}
                        {item.label}
                      </div>
                    ))}
                  </div>
                  <div className="dash-main">
                    <div className="dash-head">
                      <b>Panel general</b>
                      <span>Hoy</span>
                    </div>
                    <div className="dash-kpis">
                      <div className="kpi"><span>Ventas hoy</span><b>$ 1.842.300</b><div className="trend up">▲ 12% vs ayer</div></div>
                      <div className="kpi"><span>Caja</span><b>$ 386.500</b><div className="trend ok">✓ Arqueada</div></div>
                      <div className="kpi"><span>Pedidos</span><b>34</b><div className="trend info">8 en reparto</div></div>
                    </div>
                    <div className="dash-chart" aria-hidden="true">
                      <div className="dash-chart-head">
                        <b>Ventas de la semana</b>
                        <span>Lun — Dom</span>
                      </div>
                      <div className="dash-bars">
                        {CHART_BARS.map((bar, i) => (
                          <div key={i} className={bar.hi ? "bar hi" : "bar"} style={{ height: bar.height }} />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FLUJO / OPERACIÓN CONECTADA */}
        <section className="flow" id="plataforma" aria-labelledby="flow-heading">
          <div className="container">
            <div className="section-head" data-animate>
              <span className="kicker">Operación conectada</span>
              <h2 id="flow-heading">Un solo flujo, sin recargar datos.</h2>
              <p>No somos otro sistema administrativo: conectamos cada paso de tu operación real.</p>
            </div>
            <div className="flow-chain" data-animate>
              {FLOW_STEPS.map((step) => (
                <div key={step} className="flow-node">
                  <div className="flow-pill">{step}</div>
                  <div className="flow-link" aria-hidden="true" />
                </div>
              ))}
              <div className="flow-pill final">Decisión</div>
            </div>
          </div>
        </section>

        {/* PROBLEMA */}
        <section className="problem" aria-labelledby="problema-heading">
          <div className="container">
            <div className="section-head" data-animate>
              <span className="kicker">El problema</span>
              <h2 id="problema-heading">¿Te suena?</h2>
            </div>
            <div className="problem-grid stagger">
              <div className="problem-card" data-animate>
                <div className="tag">{"// stock_desincronizado"}</div>
                <h3>El stock nunca cierra</h3>
                <p>Entre el Excel, el depósito y el sistema viejo, nadie sabe cuánto hay de verdad.</p>
              </div>
              <div className="problem-card" data-animate>
                <div className="tag">{"// deuda_invisible"}</div>
                <h3>La cuenta corriente vive en un cuaderno</h3>
                <p>Te enterás de la deuda de un cliente cuando ya es incobrable.</p>
              </div>
              <div className="problem-card" data-animate>
                <div className="tag">{"// reparto_a_ciegas"}</div>
                <h3>El reparto se arma con papelitos</h3>
                <p>Pedidos que se pierden, entregas sin registrar, plata que no aparece.</p>
              </div>
            </div>
            <p className="problem-close" data-animate>
              Si administrás un negocio así, no es mala suerte: <strong>es falta de sistema.</strong>
            </p>
          </div>
        </section>

        {/* BENEFICIOS */}
        <section className="benefits" aria-labelledby="beneficios-heading">
          <div className="container">
            <div className="section-head" data-animate>
              <span className="kicker">Beneficios</span>
              <h2 id="beneficios-heading">Orden real, todos los días</h2>
              <p>Cuatro cosas que cambian desde la primera semana.</p>
            </div>
            <div className="benefit-grid stagger">
              <div className="benefit-card" data-animate>
                <span className="icon-badge">
                  <svg {...S} width={21} height={21}><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z" /><path d="M3 8l9 5 9-5" /><path d="M12 13v8" /></svg>
                </span>
                <h3>Stock que cierra siempre</h3>
                <p>Cada movimiento queda registrado con fecha, usuario y motivo. Transferencias, ajustes y conteos con trazabilidad completa.</p>
              </div>
              <div className="benefit-card" data-animate>
                <span className="icon-badge">
                  <svg {...S} width={21} height={21}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18" /><path d="M7 15h4" /></svg>
                </span>
                <h3>Cuenta corriente al día</h3>
                <p>Sabé cuánto te debe cada cliente antes de cargarle el próximo pedido. Cobranzas registradas al instante.</p>
              </div>
              <div className="benefit-card" data-animate>
                <span className="icon-badge">
                  <svg {...S} width={21} height={21}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg>
                </span>
                <h3>Caja controlada</h3>
                <p>Apertura, movimientos y arqueo de cada caja, todos los días. Las diferencias se ven en el momento, no a fin de mes.</p>
              </div>
              <div className="benefit-card" data-animate>
                <span className="icon-badge">
                  <svg {...S} width={21} height={21}><path d="M1 8h13v9H1z" /><path d="M14 11h4l3 3v3h-7z" /><circle cx="6" cy="18" r="1.8" /><circle cx="17" cy="18" r="1.8" /></svg>
                </span>
                <h3>Reparto ordenado</h3>
                <p>Armá las rutas, asigná los pedidos y seguí las entregas. Sin papelitos.</p>
              </div>
            </div>
          </div>
        </section>

        {/* MÓDULOS */}
        <section className="modules" id="modulos" aria-labelledby="modulos-heading">
          <div className="container">
            <div className="section-head" data-animate>
              <span className="kicker">Módulos</span>
              <h2 id="modulos-heading">Todo lo que tu operación necesita</h2>
              <p>Sin plugins ni sistemas paralelos: los módulos que se usan de verdad.</p>
            </div>
            <div className="module-grid">
              <ModuleCard title="Productos y precios" text="Catálogo con categorías, marcas, códigos de barra y listas de precios." icon={<svg {...S}><path d="M20 7H4a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1z" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>} />
              <ModuleCard title="Stock y depósitos" text="Multi-depósito con historial inmutable de movimientos." icon={<svg {...S}><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z" /><path d="M3 8l9 5 9-5" /></svg>} />
              <ModuleCard title="Ventas y pedidos" text="Del pedido a la venta sin recargar datos." icon={<svg {...S}><circle cx="9" cy="20" r="1.6" /><circle cx="18" cy="20" r="1.6" /><path d="M2 3h3l3 13h11l2-8H7" /></svg>} />
              <ModuleCard title="Cuenta corriente" text="Deuda, cobranzas e historial por cliente." icon={<svg {...S}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18" /></svg>} />
              <ModuleCard title="Caja diaria" text="Sesiones de caja con arqueo y control de diferencias." icon={<svg {...S}><rect x="2" y="6" width="20" height="12" rx="2" /><circle cx="12" cy="12" r="2.6" /></svg>} />
              <ModuleCard title="Compras y proveedores" text="Órdenes de compra, recepción y cuentas por pagar." icon={<svg {...S}><path d="M16 3h5v5" /><path d="M8 3H3v5" /><path d="M21 3l-7 7" /><path d="M3 3l7 7" /><path d="M12 14v7" /><path d="M8 21h8" /></svg>} />
              <ModuleCard title="Reparto" text="Rutas de entrega con pedidos asignados." icon={<svg {...S}><path d="M1 8h13v9H1z" /><path d="M14 11h4l3 3v3h-7z" /><circle cx="6" cy="18" r="1.6" /><circle cx="17" cy="18" r="1.6" /></svg>} />
              <ModuleCard title="Reportes" text="Ventas, stock y caja en indicadores claros." icon={<svg {...S}><path d="M3 21V7" /><path d="M8 21V3" /><path d="M13 21v-8" /><path d="M18 21V11" /></svg>} />
              <ModuleCard title="Usuarios y permisos" text="Cada empleado ve solo lo que le corresponde." icon={<svg {...S}><circle cx="9" cy="8" r="3.2" /><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6" /><path d="M17 4a3 3 0 0 1 0 6" /><path d="M19 14c2 .8 3 2.4 3 6" /></svg>} />
              <ModuleCard title="Multi-sucursal" text="Varias sucursales y depósitos en la misma cuenta." icon={<svg {...S}><path d="M3 21h18" /><path d="M5 21V7l7-4 7 4v14" /><path d="M9 21v-4h6v4" /></svg>} />
              <ModuleCard title="Importación CSV" text="Traé tus productos y clientes desde Excel en minutos." icon={<svg {...S}><path d="M12 3v12" /><path d="M7 10l5 5 5-5" /><path d="M4 21h16" /></svg>} />
              <ModuleCard soon title="Facturación electrónica" text="Preparado para ARCA." icon={<svg {...S}><path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z" /><path d="M14 3v5h5" /><path d="M9 13h6" /><path d="M9 17h6" /></svg>} />
            </div>
          </div>
        </section>

        {/* CÓMO FUNCIONA */}
        <section className="steps" id="como-funciona" aria-labelledby="pasos-heading">
          <div className="container">
            <div className="section-head" data-animate>
              <span className="kicker">Cómo funciona</span>
              <h2 id="pasos-heading">Arrancás en tres pasos</h2>
            </div>
            <div className="steps-grid stagger">
              <div className="step-card" data-animate>
                <div className="step-num">01</div>
                <h3>Creá tu cuenta</h3>
                <p>Registrate y configurá tu empresa en minutos.</p>
              </div>
              <div className="step-card" data-animate>
                <div className="step-num">02</div>
                <h3>Importá tus datos</h3>
                <p>Subí productos y clientes desde tu Excel actual.</p>
              </div>
              <div className="step-card" data-animate>
                <div className="step-num">03</div>
                <h3>Empezá a operar</h3>
                <p>Ventas, stock, caja y reparto desde el primer día.</p>
              </div>
            </div>
          </div>
        </section>

        {/* SEGURIDAD */}
        <section className="security" id="seguridad" aria-labelledby="seguridad-heading">
          <div className="container security-grid">
            <div data-animate>
              <span className="kicker">Seguridad</span>
              <h2 id="seguridad-heading">Tus datos son tuyos, y de nadie más.</h2>
              <p className="lead">
                La plataforma se diseñó desde el primer día para operar múltiples
                empresas con aislamiento total de la información.
              </p>
            </div>
            <div className="security-list stagger">
              <div className="security-item" data-animate>
                <Check />
                <div><b>Aislamiento por empresa</b><span>Cada empresa ve únicamente su información, garantizado a nivel base de datos.</span></div>
              </div>
              <div className="security-item" data-animate>
                <Check />
                <div><b>Permisos por usuario</b><span>Definís qué puede ver y hacer cada empleado.</span></div>
              </div>
              <div className="security-item" data-animate>
                <Check />
                <div><b>Auditoría</b><span>Los cambios sensibles quedan registrados, no se pueden borrar.</span></div>
              </div>
              <div className="security-item" data-animate>
                <Check />
                <div><b>Infraestructura en la nube</b><span>Respaldos y disponibilidad gestionados, sin servidores propios.</span></div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" aria-labelledby="faq-heading">
          <div className="container">
            <div className="section-head faq-head" data-animate>
              <span className="kicker">Preguntas frecuentes</span>
              <h2 id="faq-heading">Lo que siempre nos preguntan</h2>
            </div>
            <div className="faq-list" data-animate>
              <details>
                <summary>¿Necesito instalar algo? <span className="plus">+</span></summary>
                <p>No. Es 100% web: funciona desde cualquier computadora, tablet o celular con navegador.</p>
              </details>
              <details>
                <summary>¿Puedo traer mis datos de Excel? <span className="plus">+</span></summary>
                <p>Sí. Importás productos y clientes por CSV desde el primer día.</p>
              </details>
              <details>
                <summary>¿Sirve si tengo más de una sucursal? <span className="plus">+</span></summary>
                <p>Sí. Sucursales y depósitos dentro de tu plan, con stock separado por depósito.</p>
              </details>
              <details>
                <summary>¿Emite factura electrónica? <span className="plus">+</span></summary>
                <p>Estamos preparando la integración con ARCA. Hoy podés gestionar ventas, comprobantes internos y cuenta corriente; la facturación electrónica llega próximamente.</p>
              </details>
              <details>
                <summary>¿Cuánto cuesta? <span className="plus">+</span></summary>
                <p>Estamos definiendo los planes. Escribinos por WhatsApp y lo vemos según el tamaño de tu operación.</p>
              </details>
              <details>
                <summary>¿Y si necesito ayuda? <span className="plus">+</span></summary>
                <p>Te acompañamos en la puesta en marcha y tenés soporte directo por WhatsApp.</p>
              </details>
            </div>
          </div>
        </section>

        {/* CTA FINAL */}
        <section className="cta-final" id="cta-final" aria-labelledby="ctafinal-heading">
          <div className="container" data-animate>
            <h2 id="ctafinal-heading">Probá el sistema con tus propios datos.</h2>
            <p>Creá tu cuenta, importá tu Excel y mirá tu negocio ordenado por primera vez.</p>
            <div className="cta-ctas">
              <TrackedLink event="demo_start" eventProps={{ cta: "final" }} className="btn btn-primary" href="/signup">
                Probar gratis 14 días
              </TrackedLink>
              <TrackedLink
                event="whatsapp_click"
                eventProps={{ section: "cta_final" }}
                className="btn btn-ghost"
                href={CONTACT.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                Hablar por WhatsApp
              </TrackedLink>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </>
  );
}
