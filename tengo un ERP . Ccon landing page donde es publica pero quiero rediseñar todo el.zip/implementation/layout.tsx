// =============================================================================
// Layout del sitio de marketing — rediseño ejecutivo oscuro
// Reemplaza: app/(marketing)/layout.tsx
// =============================================================================
// Carga las fuentes del rediseño (Archivo + IBM Plex Mono) vía next/font y las
// expone como variables CSS que consume landing.css.
// =============================================================================

import { Archivo, IBM_Plex_Mono } from "next/font/google";
import "./landing.css";

const archivo = Archivo({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-archivo",
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
  display: "swap",
});

export default function MarketingLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div className={`landing ${archivo.variable} ${plexMono.variable}`}>
      {children}
    </div>
  );
}
