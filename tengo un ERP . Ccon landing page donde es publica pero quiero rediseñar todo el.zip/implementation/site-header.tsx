// =============================================================================
// Header del sitio de marketing — rediseño ejecutivo oscuro
// Reemplaza: app/(marketing)/_components/site-header.tsx
// =============================================================================

import Link from "next/link";
import { TrackedLink } from "./tracked-link";

export function BrandMark() {
  return (
    <span className="brand-mark">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M4 17l6-6-6-6" />
        <path d="M12 19h8" />
      </svg>
    </span>
  );
}

export function Brand() {
  return (
    <Link className="brand" href="/">
      <BrandMark />
      <span>
        Distribution<span className="accent">Platform</span>
      </span>
    </Link>
  );
}

export function SiteHeader({ withNav = true }: { withNav?: boolean }) {
  return (
    <header className="navbar" id="navbar">
      <div className="container nav-inner">
        <Brand />
        {withNav ? (
          <nav className="nav-links" aria-label="Navegación principal">
            <Link href="/#plataforma">Plataforma</Link>
            <Link href="/#modulos">Módulos</Link>
            <Link href="/#seguridad">Seguridad</Link>
            <Link href="/#faq">FAQ</Link>
          </nav>
        ) : null}
        <div className="nav-actions">
          <Link className="nav-login" href="/login">
            Ingresar
          </Link>
          <TrackedLink
            event="demo_start"
            eventProps={{ cta: "navbar" }}
            className="btn btn-primary btn-sm"
            href="/signup"
          >
            Probar gratis
          </TrackedLink>
        </div>
      </div>
    </header>
  );
}
